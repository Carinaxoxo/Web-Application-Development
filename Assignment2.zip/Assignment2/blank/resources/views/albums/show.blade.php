@extends('layouts.app')

@section('title')
    Album
@endsection

@section('content')
    <div class="album">
        <label>Album Name:</label><h1>{{$album->name}}</h1>
        <label>Aritist:</label><p>{{$album->artist->artist}}</p>
        <label>Publish Date:</label><p>{{$album->pdate}}</p>
        <label>Genre: </label><p>{{$album->genre}}</p>
        <label>Description : </label><p>{{$album->description}}</p>
        
        @if (Auth::user() && Auth::user()->role == 'moderator')
        <p><a href="/album/{{$album->id}}/edit">Edit</a></p>
        <p>
            <form method="POST" action="/album/{{$album->id}}">
                {{csrf_field()}}
                {{ method_field('DELETE') }}
                <input type="submit" value="Delete">
            </form>
        </p>
        @endif
    </div>
    
    
    <br>
    <br>
    
    @if (count($photos) > 0)
        <label>Album photos: </label>
        @foreach($photos as $photo)
            <div class="photo">
                <img src="{{url($photo->image)}}" alt="album image"style="width:300px;height:300px;">
                <br>
                @if ($photo->user_id == 0)
                    <label>Default Image</label>
                @else
                    <label>Upload User: {{$photo->user->first_name}} {{$photo->user->last_name}}</label>
                @endif
                @if (Auth::user() && (Auth::user()->role == 'moderator' || Auth::user()->id == $photo->user_id))
                    <p>
                        <form method="POST" action="/album/{{$album->id}}/photo/{{$photo->id}}">
                            {{csrf_field()}}
                            {{ method_field('DELETE') }}
                            <input type="submit" value="Delete">
                        </form>
                    </p>
                @endif
                <br>
            </div>
        @endforeach
    @endif
    <br>
    @if (Auth::user())
        <a href="/album/{{$album->id}}/photo/create">Upload a new photo</a>
        <br>
    @endif
    <br>
    <br>
    
    @if (count($reviews) > 0)
        <p><a href="/album/{{$album->id}}/orderby">List reviews by rating</a></p>
        <p><a href="/album/{{$album->id}}">List reviews by date</a></p>
        @foreach($reviews as $review)
          @if ($review->like > $review->dislike)
              <div class="popular">
                <a href="/user/{{$review->user_id}}"><label>User: {{$review->user->first_name}} {{$review->user->last_name}}</label></a>
                @if (Auth::user() && Auth::user()->id != $review->user_id)
                    <a href="/album/{{$album->id}}/user/{{$review->user_id}}/follow">
                       <input type="button" value="Follow" />
                    </a>
                    <a href="/album/{{$album->id}}/user/{{$review->user_id}}/unfollow">
                       <input type="button" value="Unfollow" />
                    </a>
                @endif
                <br>
                <br>
                <label>Review: </label><p>{{$review->review}}</p>
                <label>Rating: {{$review->rating}}</label>
                <br>
                <br>
                <label>Publish Date: {{$review->created_at}}    Edit Date: {{$review->updated_at}}</label>
                <div class="like">
                    <a href="/album/{{$review->album_id}}/review/{{$review->id}}/like">
                       <input type="button" value="Like" />
                    </a><p>{{$review->like}}</p>
                    <a href="/album/{{$review->album_id}}/review/{{$review->id}}/dislike">
                       <input type="button" value="Dislike" />
                    </a><p>{{$review->dislike}}</p>
                </div>
                @if (Auth::user() && (Auth::user()->role == 'moderator' || Auth::user()->id == $review->user_id))
                    <p><a href="/album/{{$album->id}}/review/{{$review->id}}/edit">Edit</a></p>
                    <p>
                        <form method="POST" action="/album/{{$album->id}}/review/{{$review->id}}">
                            {{csrf_field()}}
                            {{ method_field('DELETE') }}
                            <input type="submit" value="Delete">
                        </form>
                    </p>
                @endif
            </div>
          @else
              <div class="review">
                <a href="/user/{{$review->user_id}}"><label>User: {{$review->user->first_name}} {{$review->user->last_name}}</label></a>
                @if (Auth::user() && Auth::user()->id != $review->user_id)
                    <a href="/album/{{$album->id}}/user/{{$review->user_id}}/follow">
                       <input type="button" value="Follow" />
                    </a>
                    <a href="/album/{{$album->id}}/user/{{$review->user_id}}/unfollow">
                       <input type="button" value="Unfollow" />
                    </a>
                @endif
                <br>
                <br>
                <label>Review: </label><p>{{$review->review}}</p>
                <label>Rating: {{$review->rating}}</label>
                <br>
                <br>
                <label>Publish Date: {{$review->created_at}}    Edit Date: {{$review->updated_at}}</label>
                <div class="like">
                    <a href="/album/{{$review->album_id}}/review/{{$review->id}}/like">
                       <input type="button" value="Like" />
                    </a><p>{{$review->like}}</p>
                    <a href="/album/{{$review->album_id}}/review/{{$review->id}}/dislike">
                       <input type="button" value="Dislike" />
                    </a><p>{{$review->dislike}}</p>
                </div>
                @if (Auth::user() && (Auth::user()->role == 'moderator' || Auth::user()->id == $review->user_id))
                    <p><a href="/album/{{$album->id}}/review/{{$review->id}}/edit">Edit</a></p>
                    <p>
                        <form method="POST" action="/album/{{$album->id}}/review/{{$review->id}}">
                            {{csrf_field()}}
                            {{ method_field('DELETE') }}
                            <input type="submit" value="Delete">
                        </form>
                    </p>
                @endif
            </div>
          @endif
        @endforeach
    @endif
    
    {{ $reviews->links() }}
    
    @if (Auth::user())
        <a href="/album/{{$album->id}}/review/create">Create a new review</a>
        <br>
    @endif
    
    <a href="/album">Index</a>
@endsection