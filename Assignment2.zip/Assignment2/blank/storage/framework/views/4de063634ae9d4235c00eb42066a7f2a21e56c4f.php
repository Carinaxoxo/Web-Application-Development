<?php $__env->startSection('title'); ?>
    Error
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    You have already <?php echo e($error); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>