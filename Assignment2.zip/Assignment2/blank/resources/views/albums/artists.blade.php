@extends('layouts.app')

@section('title')
    Artists
@endsection

@section('content')
<ul>
    @foreach($artists as $artist)
        <a href="/artist/{{$artist->id}}"><li>{{$artist->artist}}</li></a>
    @endforeach

</ul>
@endsection