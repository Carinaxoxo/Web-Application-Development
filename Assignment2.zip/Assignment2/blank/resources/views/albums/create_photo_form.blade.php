@extends('layouts.app')

@section('title')
    Photo
@endsection

@section('content')
    <h1>Upload a photo</h1>
    @if (count($errors) > 0)
      <div class="alert">
          <ul>
              @foreach ($errors->all() as $error)
                <li>{{$error}}</li>
              @endforeach
          </ul>
      </div>
    @endif
    <div class="form">
      <form method="POST" action="/album/{{$album_id}}/photo" enctype="multipart/form-data">
        {{csrf_field()}}
        <p><input type="file" name="image"></p>
        <p><input type="hidden" name="album_id" value="{{$album_id}}"></p>
        <p><input type="hidden" name="user_id" value="{{Auth::user()->id}}"></p>
        <input type="submit" value="Create">
      </form>
    </div>
    
@endsection