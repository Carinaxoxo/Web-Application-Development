@extends('layouts.app')

@section('title')
    Error
@endsection

@section('content')
    You have already {{$error}}
@endsection