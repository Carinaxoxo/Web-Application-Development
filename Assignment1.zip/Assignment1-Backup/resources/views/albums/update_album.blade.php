@extends('layouts.master')

@section('title')
  Update Album
@endsection

@section('content')
    <h1>Update Album</h1>
    <form method="post" action="/update_album_action" class="form">
    {{csrf_field()}}
        <input type="hidden" name="id" value="{{$album->id}}">
        <p>
        <label>Album Name: </label>
        <input type="text" name="name" value="{{$album->name}}">
        </p>
        <p>
        <label>Aritist: </label>
        <input type="text" name="artist" value="{{$album->artist}}">
        </p>
        <p>
        <label>Publish Date: </label>
        <input type="text" name="pdate" value="{{$album->pdate}}">
        </p>
        <p>
        <label>Genre: </label>
        <input type="text" name="genre" value="{{$album->genre}}">
        </p>
        <input type="submit" value="Update item">
    </form>
    <br>
    @if (!empty($eMessage))
      {{$eMessage}}
    @endif
@endsection