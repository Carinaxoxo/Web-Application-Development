@extends('layouts.master')

@section('title')
  Updating review form
@endsection

@section('content')
      <h1>Update Review</h1>
      <form method="post" action="/update_review_action" class="form">
            {{csrf_field()}}
            <input type="hidden" name="id" value="{{$review->id}}">
            <p>
              <label>Date:</label>
              <input type="text" name="rdate" value="{{$review->rdate}}">
            </p>
            <p>
              <label>Review:</label>
              <input type="text" name="review" value="{{$review->review}}">
            </p>
            <p>
              <label>Rating:</label>
              <input type="text" name="rating" value="{{$review->rating}}">
            </p>
            <input type="submit" value="Submit">
      </form>
      <br>
  @if (!empty($eMessage))
    <p style="background-color:Tomato; width: 20%; padding: 15px 30px;">{{$eMessage}}</p>
  @endif
@endsection