<?php $__env->startSection('title'); ?>
    Review
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Create a new review</h1>
    <?php if(count($errors) > 0): ?>
      <div class="alert">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <div class="form">
        <form method="POST" action="/album/<?php echo e($album_id); ?>/review">
            <?php echo e(csrf_field()); ?>

            <p><input type="hidden" name="album_id" value="<?php echo e($album_id); ?>"></p>
            <p><input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>"></p>
            <p><label>Rating: </label><input type="number" name="rating" value="<?php echo e(old('rating')); ?>"></p>
            <p><label>Review: </label><textarea rows="4" cols="50" name="review" value="<?php echo e(old('review')); ?>"></textarea>
            <p><input type="hidden" name="like" value="0"></p>
            <p><input type="hidden" name="dislike" value="0"></p>
            <input type="submit" value="Create"> 
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>