@extends('layouts.app')

@section('title')
    Album
@endsection

@section('content')
    <h1>Edit a new Album</h1>
    @if (count($errors) > 0)
      <div class="alert">
          <ul>
              @foreach ($errors->all() as $error)
                <li>{{$error}}</li>
              @endforeach
          </ul>
      </div>
    @endif
    <div class="edit">
        <form method="POST" action="/album/{{$album->id}}">
        {{csrf_field()}}
        {{method_field('PUT')}}
            </p><label>Name</label>
            <input type="text" name="name" value="{{$album->name}}"></p>
            <p>
                <label>Artist: </label>
                <select name="artist_id">
                @foreach ($artists as $artist)
                    @if($artist->id == $album->artist_id)
                        <option value="{{$artist->id}}" selected="selected">{{$artist->artist}}</option>
                    @else
                        <option value="{{$artist->id}}">{{$artist->artist}}</option>
                    @endif
                @endforeach
            </select>
            </p>
            <p><label>Pulish Date: </label><input type="date" name="pdate" value="{{$album->pdate}}"></p>
            <p>
                <label>Genre: </label>
                <select name="genre">
                @foreach ($genres as $genre)
                    @if($album->genre == $genre->genre)
                        <option value="{{$genre->genre}}" selected="selected">{{$genre->genre}}</option>
                    @else
                        <option value="{{$genre->genre}}">{{$genre->genre}}</option>
                    @endif
                @endforeach
            </select>
            </p>
            <input type="submit" value="Update">
        </form>
    </div>
    
@endsection