<?php $__env->startSection('title'); ?>
    Album
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit a new Album</h1>
    <?php if(count($errors) > 0): ?>
      <div class="alert">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <div class="edit">
        <form method="POST" action="/album/<?php echo e($album->id); ?>">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>

            </p><label>Name</label>
            <input type="text" name="name" value="<?php echo e($album->name); ?>"></p>
            <p>
                <label>Artist: </label>
                <select name="artist_id">
                <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($artist->id == $album->artist_id): ?>
                        <option value="<?php echo e($artist->id); ?>" selected="selected"><?php echo e($artist->artist); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($artist->id); ?>"><?php echo e($artist->artist); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </p>
            <p><label>Pulish Date: </label><input type="date" name="pdate" value="<?php echo e($album->pdate); ?>"></p>
            <p>
                <label>Genre: </label>
                <select name="genre">
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($album->genre == $genre->genre): ?>
                        <option value="<?php echo e($genre->genre); ?>" selected="selected"><?php echo e($genre->genre); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($genre->genre); ?>"><?php echo e($genre->genre); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </p>
            <input type="submit" value="Update">
        </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>