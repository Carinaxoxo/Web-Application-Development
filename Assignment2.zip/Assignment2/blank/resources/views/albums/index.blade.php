@extends('layouts.app')

@section('title')
    Albums
@endsection

@section('content')
<ul>
    @foreach($albums as $album)
        <a href="/album/{{$album->id}}"><li>{{$album->name}}</li></a>
    @endforeach
    <br>
    <br>
    <a href="/album/create">Create a new album</a>
    <br><br><br>
    <a href="/document">Documentation</a>
    <br>
    <a href="/erd">ERDiagram</a>
</ul>
@endsection