@extends('layouts.master')

@section('title')
  Welcome to the music world - Genres
@endsection

@section('content')
  <h1>{{$albums[0]->genre}}</h1>
  @if($albums)
    @foreach($albums as $album)
      <br>
      <div class="album">
          <p>Album Name: <a href="{{url("album_detail/$album->id")}}">{{$album -> name}}</a></p>
          <p>Artist: <a href="{{url("artist_album/$album->artist")}}">{{$album -> artist}}</a></p>
          <p>Publish Date: {{$album -> pdate}}</p>
          <p>Genre: <a href="{{url("genre_album/$album->genre")}}"></a>{{$album -> genre}}</p>
      </div>
      <br>
    @endforeach
  @endif
@endsection