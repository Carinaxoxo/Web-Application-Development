<?php $__env->startSection('title'); ?>
    Album
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit the Review</h1>
    <?php if(count($errors) > 0): ?>
      <div class="alert">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <div class="edit">
        <form method="POST" action="/album/<?php echo e($album_id); ?>/review/<?php echo e($review->id); ?>">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>

            <p><input type="hidden" name="album_id" value="<?php echo e($review->album_id); ?>"></p>
            <p><input type="hidden" name="user_id" value="<?php echo e($review->user_id); ?>"></p>
            <p><label>Rating: </label><input type="number" name="rating" value="<?php echo e($review->rating); ?>"></p>
            <p><label>Review: </label><textarea rows="4" cols="50" name="review" value="<?php echo e($review->review); ?>"></textarea>
            <p><input type="hidden" name="like" value="<?php echo e($review->like); ?>"></p>
            <p><input type="hidden" name="dislike" value="<?php echo e($review->dislike); ?>"></p>
            <input type="submit" value="Update"> 
        </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>