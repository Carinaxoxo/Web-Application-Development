<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(UsersTableSeeder::class);
        $this->call(AlbumsTableSeeder::class);
        $this->call(ArtistsTableSeeder::class);
        $this->call(ReviewsTableSeeder::class);
        $this->call(FollowsTableSeeder::class);
        //$this->call(LikesTableSeeder::class);
        $this->call(PhotosTableSeeder::class);
        $this->call(RecommendsTableSeeder::class);
    }
}
