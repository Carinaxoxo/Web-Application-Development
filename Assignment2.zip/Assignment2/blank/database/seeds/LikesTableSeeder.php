<?php

use Illuminate\Database\Seeder;

class LikesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('likes')->insert([
        'review_id' => '1',
        'user_id' => '1',
        'vote' => 'like',
        ]);
        DB::table('likes')->insert([
        'review_id' => '2',
        'user_id' => '2',
        'vote' => 'like',
        ]);
        DB::table('likes')->insert([
        'review_id' => '3',
        'user_id' => '3',
        'vote' => 'like',
        ]);
        DB::table('likes')->insert([
        'review_id' => '4',
        'user_id' => '4',
        'vote' => 'like',
        ]);
        DB::table('likes')->insert([
        'review_id' => '5',
        'user_id' => '5',
        'vote' => 'like',
        ]);
        
    }
}
