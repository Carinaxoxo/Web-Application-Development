@extends('layouts.app')

@section('title')
    Review
@endsection

@section('content')
    <h1>Create a new review</h1>
    @if (count($errors) > 0)
      <div class="alert">
          <ul>
              @foreach ($errors->all() as $error)
                <li>{{$error}}</li>
              @endforeach
          </ul>
      </div>
    @endif
    <div class="form">
        <form method="POST" action="/album/{{$album_id}}/review">
            {{csrf_field()}}
            <p><input type="hidden" name="album_id" value="{{$album_id}}"></p>
            <p><input type="hidden" name="user_id" value="{{Auth::user()->id}}"></p>
            <p><label>Rating: </label><input type="number" name="rating" value="{{old('rating')}}"></p>
            <p><label>Review: </label><textarea rows="4" cols="50" name="review" value="{{old('review')}}"></textarea>
            <p><input type="hidden" name="like" value="0"></p>
            <p><input type="hidden" name="dislike" value="0"></p>
            <input type="submit" value="Create"> 
        </form>
    </div>

@endsection