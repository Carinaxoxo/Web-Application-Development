@extends('layouts.master')

@section('title')
  Adding form
@endsection

@section('content')
  <h1>Add Album</h1>
  <form method="post" action="/add_album_action" class="form">
  {{csrf_field()}}
    <p>
      <label>Album Name:</label>
      <input type="text" name="name">
    </p>
    <p>
      <label>Artist:</label>
      <input type="text" name="artist">
    </p>
    <p>
      <label>Pubshi Date:</label>
      <input type="text" name="pdate">
    </p>
    <p>
      <label>Genre:</label>
      <input type="text" name="genre">
    </p>
    <input type="submit" value="Submit">
  </form>
  <br>
  @if (!empty($eMessage))
    <p style="background-color:Tomato; width: 20%; padding: 15px 30px;">{{$eMessage}}</p>
  @endif
@endsection