@extends('layouts.master')

@section('title')
  Welcome to the music world - Home
@endsection

@section('content')
  <div id="HomeBody">
      <h1 style="float: left;">WHAT'S NEW!</h1>
      <div id = "newcover"></div>
  </div> 
@endsection