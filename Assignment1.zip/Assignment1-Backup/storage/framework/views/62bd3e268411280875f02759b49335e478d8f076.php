<?php $__env->startSection('title'); ?>
  Album
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('content'); ?>
      <div class="album">
          <p>Album Name: <?php echo e($album->name); ?></p>
          <p>Artist: <a href="<?php echo e(url("artist_album/$album->artist")); ?>"><?php echo e($album->artist); ?></a></p>
          <p>Publish Date: <?php echo e($album->pdate); ?></p>
          <p>Genre: <a href="<?php echo e(url("genre_album/$album->genre")); ?>"><?php echo e($album->genre); ?></a></p>
      </div>
      <br>
      <br>
      <br>
      <p class="reviewnumber">The number of reviews: <?php echo e($number); ?></p>
        <?php if(!empty($reviews)): ?>
          <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($review->review)): ?>
            <div class="review">
                <p>User Name: <?php echo e($review->username); ?></p>
                <p>Review: <?php echo e($review->review); ?></p>
                <p>Date: <?php echo e($review->rdate); ?></p>
                <p>Rating: <?php echo e($review->rating); ?></p>
                <a href="<?php echo e(url("update_review/$review->review_id")); ?>"> Update this review</a> <br>
                <a href="<?php echo e(url("delete_review/$review->review_id")); ?>"> Delete this review</a>
            </div>
            <br>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
<p><a href="<?php echo e(url("add_review")); ?>">Add an review</a></p>
<p><a href="<?php echo e(url("update_album/$album->album_id")); ?>"> Update album </a></p>
<p><a href="<?php echo e(url("delete_album/$album->album_id")); ?>"> Delete album </a></p>
<p><a href="/"> Home </a></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>