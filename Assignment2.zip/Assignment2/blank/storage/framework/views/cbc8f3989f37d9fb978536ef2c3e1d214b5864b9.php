<?php $__env->startSection('title'); ?>
    Album
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Create a new Album</h1>
    <?php if(count($errors) > 0): ?>
      <div class="alert">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <div class="form">
        <form method="POST" action="/album">
            <?php echo e(csrf_field()); ?>

            <p><label>Name: </label><input type="text" name="name" value="<?php echo e(old('name')); ?>"></p>
            <p><label>Artist: </label><input type="text" name="artist" value="<?php echo e(old('artist')); ?>"></p>
            <p><label>Pulish Date: </label><input type="date" name="pdate" value="<?php echo e(old('pdate')); ?>"></p>
            <p><label>Genre: </label><input type="text" name="genre" value="<?php echo e(old('genre')); ?>"></p>
            <p><label>Description: </label><textarea rows="4" cols="50" name="description" value="<?php echo e(old('description')); ?>"></textarea>
            <br>
            <input type="submit" value="Create"> 
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>