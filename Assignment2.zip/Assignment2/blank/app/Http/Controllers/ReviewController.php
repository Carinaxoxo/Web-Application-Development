<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Album;
use App\Artist;
use App\Review;
use App\Photo;
use App\Recommend;
use App\Like;
use Auth;

class ReviewController extends Controller
{
    public function __construct() {
         $this->middleware('auth', ['except'=>['show']]);
         //restrict the access
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        //
        if (Review::whereRaw('user_id = ? and album_id = ?', array(Auth::user()->id, $id))->exists()) {
            $error = 'reviewed';
            return view('albums.forbid')->with('error', $error);
        } else {
            return view('albums.create_review_form')->with('album_id', $id);
        }//to check if the current user has already posted a review to the same album
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        
        $this->validate($request, [
            'album_id' => 'required',
            'user_id' => 'required',
            'rating' => 'required|min:0',
            'review' => 'required|string',
            'like' => 'required',
            'dislike' => 'required'
        ]);
        $review = new Review();
        $review->album_id = $request->album_id;
        $review->user_id = $request->user_id;
        $review->rating = $request->rating;
        $review->review = $request->review;
        $review->like = $request->like;
        $review->dislike = $request->dislike;
        $review->save();
        if (Auth::user()) {
            $recommend = new Recommend();
            $recommend->user_id = $request->user_id;
            $album = Album::find($request->album_id);
            $recommend->keyword = $album->genre;
            $recommend->save();
        }
        //check to see if there is needed to add a recommendation

        return redirect("/album/$review->album_id");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $album = Album::find($id);
        $reviews = Review::where('album_id', '=', $id)->get();
        return view('albums.show')->with('album', $album)->with('reviews', $reviews);
        //list the details of the album
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($album_id, $review_id)
    {
        //
        $review = Review::find($review_id);
        return view('albums.edit_review_form')->with('review', $review)->with('album_id', $album_id);
        //add a review
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $album_id, $review_id)
    {
        //
        $this->validate($request, [
            'album_id' => 'required',
            'user_id' => 'required',
            'rating' => 'required|min:0',
            'review' => 'required|string',
            'like' => 'required',
            'dislike' => 'required'
        ]);
        $review = Review::find($review_id);
        $review->album_id = $request->album_id;
        $review->user_id = $request->user_id;
        $review->rating = $request->rating;
        $review->review = $request->review;
        $review->like = $request->like;
        $review->dislike = $request->dislike;
        $review->save();
        //update it
        
        return redirect("/album/$review->album_id");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($album_id, $review_id)
    {
        //
        $review = Review::find($review_id);
        $review->delete();
        return redirect("album/$album_id");
        //delete a review
    }
}
