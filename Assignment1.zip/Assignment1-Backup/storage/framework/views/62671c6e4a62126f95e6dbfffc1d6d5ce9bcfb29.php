<!DOCTYPE html>
<html>
<head>
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="<?php echo e(secure_asset('css/wp.css')); ?>">
</head>

<body>
  <div class="banner-image">
    <div class="banner-text">
    <h1>Welcome to the music world</h1>
    <p>Here you can have fun with music</p>
    </div>
  </div>
  <div id="navbar">
      <ul>
          <li><a href="/">Home</a></li>
          <li><a href="<?php echo e(url("/albums")); ?>">Albums</a></li>
          <li><a href="<?php echo e(url("/artists")); ?>">Artists</a></li>
          <li><a href="<?php echo e(url("/genres")); ?>">Genres</a></li>
          <li><a href="<?php echo e(url("/reviews")); ?>">Reviews</a></li>
          <li><a href="<?php echo e(url("/ratings")); ?>">Rating</a></li>
          <li><a href="<?php echo e(url("/document")); ?>">Document</a></li>
          <li><a href="<?php echo e(url("/erd")); ?>">ER Diagram</a></li>
      </ul>
  </div>
  <br>
  <br>
    <?php echo $__env->yieldContent('content'); ?>
</body>