<?php $__env->startSection('title'); ?>
  Welcome to the music world - Artists
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>Artists list</h1>
  <?php if($artists): ?>
    <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <br>
      <div class="artist">
          <p><a href="<?php echo e(url("artist_album/$artist->artist")); ?>"><?php echo e($artist->artist); ?></a></p>
      </div>
      <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>