drop table if exists album;
create table album (    
    id integer not null primary key autoincrement,    
    name varchar(80) not null,    
    artist varchar(80) not null, 
    pdate varchar(80) not null, 
    genre varchar(80) not null
); 

insert into album values (null, "KOD", "J Cloe", "20 April, 2018", "Conscious rap");
insert into album values (null, "Let Go", "Avril Lavigne", "4 June, 2002", "Alternative rock");
insert into album values (null, "Recovery", "Eminem", "18 June, 2010", "Hip hop");
insert into album values (null, "Everybody", "Logic", "15 May, 2017", "Conscious rap");
insert into album values (null, "Reputation", "Taylor Swift", "10 November, 2017", "Pop");

drop table if exists review;
create table review (    
    id integer not null primary key autoincrement,    
    user_id integer,    
    album_id integer,
    review text default '',
    rdate varchar(80),
    rating float,
    foreign key (album_id) references album(id),
    foreign key (user_id) references user(id)
); 

insert into review values (null, 1, 1, "He did it great", "20 April, 2018", 4.0);
insert into review values (null, 2, 1, "He hard as hell", "20 April, 2018", 4.5);
insert into review values (null, 2, 2, "Where is AL6", "4 June, 2018", 5.0);
insert into review values (null, 3, 3, "The coolest man ever", "18 June, 2018", 5.0);
insert into review values (null, 4, 4, "The greatest Bobby",  "20 May, 2017", 5.0);
insert into review values (null, 5, 5, "No one else like her", "10 November, 2017", 5.0);

drop table if exists user;
create table user (
    id integer not null primary key autoincrement,  
    name varchar(50) not null
);

insert into user values (null, "Cody");
insert into user values (null, "Cindy");
insert into user values (null, "Sean");
insert into user values (null, "Bobby");
insert into user values (null, "Sally");