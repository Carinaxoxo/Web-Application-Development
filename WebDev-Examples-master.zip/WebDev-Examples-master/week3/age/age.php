<?php
$name = $_GET['name'];
$age = $_GET['age'];
echo "$name is $age years old.";
?>
