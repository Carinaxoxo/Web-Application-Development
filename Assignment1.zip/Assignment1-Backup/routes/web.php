<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('home');
});

Route::get('/albums', function() {
    $sql = "select * from album";
    $albums = DB::select($sql);
    return view('albums.album_list')->with('albums', $albums);
});

Route::get('artists', function(){
    $sql = "select distinct artist from album";
    $artists = DB::select($sql);
    return view('albums.artist_list')->with('artists', $artists);
});

Route::get('genres', function(){
    $sql = "select distinct genre from album";
    $genres = DB::select($sql);
    return view('albums.genre_list')->with('genres', $genres);
});

Route::get('reviews', function(){
    $sql = "select album.id, album.name, album.artist, album.pdate, album.genre, count(review.id) as reviewsCount
            from review, album where review.album_id = album.id and review.review not null group by album.id order by count(review.id) desc";
    $albums = DB::select($sql);
    //dd($albums);
    $sql = "select album.id, album.name, album.artist, album.pdate, album.genre, count(review.id)-1 as reviewsCount
            from review, album where review.album_id = album.id and review.review is null group by album.id";
    $other_albums = DB::select($sql);
    return view('albums.album_review')->with('albums', $albums)->with('other_albums', $other_albums);
});

Route::get('ratings', function(){
    $sql = "select album.id, album.name, album.artist, album.pdate, album.genre, avg(review.rating) as avgRating
           from album, review where review.album_id = album.id group by album.id order by avg(review.rating) desc";
    $albums = DB::select($sql);
    return view('albums.rating_list')->with('albums', $albums);
});

Route::get('document', function() {
    return view('albums.document');
});

Route::get('erd', function() {
    return view('albums.erd');
});

Route::get('album_detail/{id}', function($id) {
    $sql = "select album.id as album_id, album.name, album.artist, album.pdate, album.genre,
                          review.id as review_id, review.review, review.rdate, review.rating,
                          user.name as username
                   from album, review, user 
                   where album.id = review.album_id and review.user_id = user.id and album.id = ?";
    $reviews = DB::select($sql, array($id));
    if (empty($reviews)) {
        $sql = "select album.id as album_id, album.name, album.artist, album.pdate, album.genre
                from album where album.id = ?";
        $album_info = DB::select($sql, array($id));
        $album = $album_info[0];
    } else {
        $album = $reviews[0];
    }
    $sql = "select * from review, album where review.album_id = album.id and album.id = ?";
    $rnumber = DB::select($sql, array($id));
    $number = 0;
    for ($i = 0; $i < count($rnumber); $i++) {
        if (!empty($rnumber[$i]->review)) {
            $number += 1;
        }
    }
    return view('albums.album_detail')->with('reviews', $reviews)->with('album', $album)->with('number', $number);
});

Route::get('artist_album/{artist}', function($artist) {
    $sql = "select * from album where album.artist = ?";
    $albums = DB::select($sql, array($artist));
    return view('albums.artist_album')->with('albums', $albums);
});

Route::get('genre_album/{genre}', function($genre) {
    $sql = "select * from album where album.genre = ?";
    $albums = DB::select($sql, array($genre));
    return view('albums.genre_album')->with('albums', $albums);
});

Route::get('add_album', function() {
    return view('albums.add_album');
});

Route::get('add_review', function() {
    return view('albums.add_review');
});

Route::get('update_album/{id}', function($id) {
    $album = get_album($id);
    return view('albums.update_album')->with('album', $album);
});

Route::get('update_review/{id}', function($id) {
    $review = get_review($id);
    return view('albums.update_review')->with('review', $review);
});

Route::get('delete_album/{id}', function($id) {
    delete_album($id);
    $sql = "select * from album";
    $albums = DB::select($sql);
    return view('albums.album_list')->with('albums', $albums);
});

Route::get('delete_review/{id}', function($id) {
    delete_review($id);
    $sql = "select * from album";
    $albums = DB::select($sql);
    return view('albums.album_list')->with('albums', $albums);
});

Route::post('add_album_action', function() {
    $name = htmlspecialchars(request('name')); //retrive the key
    $artist = htmlspecialchars(request('artist'));
    $pdate = htmlspecialchars(request('pdate'));
    $genre = htmlspecialchars(request('genre'));
    $eMessage = albumerror($name, $artist, $pdate, $genre);
    if ($eMessage) {
        return view("albums.add_album")->with('eMessage', $eMessage);
    } else {
        $id  = add_album($name, $artist, $pdate, $genre);
        if ($id) {
            return redirect("album_detail/$id");
        } else {
            die('Error while adding album');
        }
    }
});

Route::post('add_review_action', function() {
    $username = htmlspecialchars(request('username')); //retrive the key
    $rdate = htmlspecialchars(request('rdate'));
    $review = htmlspecialchars(request('review'));
    $rating = htmlspecialchars(request('rating'));
    $albumname = htmlspecialchars(request('albumname'));

    $eMessage = reviewerror($username, $rdate, $review, $rating, $albumname);
    if ($eMessage) {
        return view("albums.add_review")->with('eMessage', $eMessage);
    } else {
        $id = add_review($username, $rdate, $review, $rating, $albumname);
        if ($id) {
            return redirect("album_detail/$id");
        } else {
            die('Error while adding album');
        }
    }
});

Route::post('update_album_action', function() {
    $name = htmlspecialchars(request('name')); //retrive the key
    $artist = htmlspecialchars(request('artist'));
    $pdate = htmlspecialchars(request('pdate'));
    $genre = htmlspecialchars(request('genre'));
    $id = htmlspecialchars(request('id'));
    update_album($id, $name, $artist, $pdate, $genre);
    
    if ($id) {
        return redirect("album_detail/$id");
    } else {
        die('Error while updating album');
    }
    
    /*$eMessage = albumerror($name, $artist, $pdate, $genre);
    if ($eMessage) {
        return view("update_album/$id")->with('eMessage', $eMessage);
    } else {
        update_album($id, $name, $artist, $pdate, $genre);
        if ($id) {
            return redirect("album_detail/$id");
        } else {
            die('Error while adding album');
        }
    } */
    //$eMessage = albumerror($name, $artist, $pdate, $genre);
    //if ($eMessage) {
        //$sql = "select * from album where id = ?";
        //$album = DB::select($sql, array($id));
        //dd($album[0]->id);
        //$albumid = $album[0]->id;
    //    return view("update_album/$id")->with('eMessage', $eMessage);
    //} else {
    //    $id  = add_album($name, $artist, $pdate, $genre);
    //    if ($id) {
    //        return redirect("album_detail/$id");
    //    } else {
    //        die('Error while updating album');
    //   }
    //}
});

Route::post('update_review_action', function() {
    $rdate = htmlspecialchars(request('rdate'));
    $review = htmlspecialchars(request('review'));
    $rating = htmlspecialchars(request('rating'));
    $id = htmlspecialchars(request('id'));
    
    update_review($id, $rdate, $review, $rating);
    $sql = "select album_id from review where id = ?";
    $albumid = DB::select($sql, array($id));
    $album_id = $albumid[0]->album_id;
    if ($album_id) {
        return redirect("album_detail/$album_id");
    } else {
        die('Error while updating review');
    } 
    /*$eMessage = reviewerror($username, $rdate, $review, $rating, $albumname);
    if ($eMessage) {
        return view("update_review/$id")->with('eMessage', $eMessage);
    } else {
        update_review($id, $rdate, $review, $rating);
        $sql = "select album_id from review where id = ?";
        $albumid = DB::select($sql, array($id));
        $album_id = $albumid[0]->album_id;
        if ($album_id) {
            return redirect("album_detail/$album_id");
        } else {
            die('Error while updating review');
        }
    }*/
});

function add_album($name, $artist, $pdate, $genre) {
    $sql = "insert into album (name, artist, pdate, genre) values (?, ?, ?, ?)";
    DB::insert($sql, array($name, $artist, $pdate, $genre));
    $id = DB::getPdo()->lastInsertId();
    $sql = "insert into review (user_id, album_id, review, rdate, rating) values (null, ?, null, null, null)";
    DB::insert($sql, array($id));
    return ($id);
}

function add_review($username, $rdate, $review, $rating, $albumname) {
    $sql = "insert into user (name) values (?)";
    DB::insert($sql, array ($username));
    $user_id = DB::getPdo()->lastInsertId();
    $sql = "select id from album where album.name=?";
    $album_id = DB::select($sql, array($albumname));
    $albumid = $album_id[0]->id;
    $sql = "insert into review (user_id, album_id, review, rdate, rating) values (?, ?, ?, ?, ?)";
    DB::insert($sql, array($user_id, $albumid, $review, $rdate, $rating));
    return ($albumid);
}

function update_album($id, $name, $artist, $pdate, $genre) {
    $sql = "update album set name = ?, artist = ?, pdate = ?, genre = ? where id = ?";
    DB::update($sql, array($name, $artist, $pdate, $genre, $id));
}

function update_review($id, $rdate, $review, $rating) {
    $sql = "update review set review = ?, rdate = ?, rating = ? where id = ?";
    DB::update($sql, array($review, $rdate, $rating, $id));
}

function delete_album($id) {
    $sql = "delete from album where id = ?";
    DB::delete($sql, array($id));
} 

function delete_review($id) {
    $sql = "delete from review where id = ?";
    DB::delete($sql, array($id));
} 

function get_album($id) {
    $sql = "select * from album where id=?";
    $albums = DB::select($sql, array ($id));
    
    if (count($albums) != 1) {
        die("Something has gone wrong, invalid query or result: $sql");
    }
    
    $album = $albums[0];
    return $album;
}

function get_review($id) {
    $sql = "select * from review where id=?";
    $reviews = DB::select($sql, array ($id));
    
    if (count($reviews) != 1) {
        die("Something has gone wrong, invalid query or result: $sql");
    }
    
    $review = $reviews[0];
    return $review;
}

function albumerror($name, $artist, $pdate, $genre) {
    if (empty($artist)) {
        return ('Album must have a artist');
    }
    if (empty($name) || empty($pdate) || empty ($genre)) {
        return ('no field can be empty');
    }
    $sql = "select * from album where name = ? and artist = ?";
    $error = DB::select($sql, array($name, $artist));
    if ($error) {
        return ('Album must have a unique name');
    }
    return false;
}

function reviewerror($username, $rdate, $review, $rating, $albumname) {
    if (empty($username) ||empty($rdate) ||empty($review) ||empty($rating) ||empty($albumname)) {
        return ('no field can be empty');
    }
    if (is_int($rating) || $rating > 5.0 || $rating < 1.0) {
        return ('rating must a float number between 1.0 and 5.0');
    }
    $sql = "select id from user where name = ?";
    $userid = DB::select($sql, array($username));
    if (empty($userid)) {
        return false;
    }
    $user_id = $userid[0]->id;
    $sql = "select id from album where album.name=?";
    $albumid = DB::select($sql, array($albumname));
    $album_id = $albumid[0]->id;
    $sql = "select * from review, album, user where user_id = ? and album_id = ? and user.name = ? and album.name = ?";
    $error = DB::select($sql, array($user_id, $album_id, $username, $albumname));
    if ($error) {
        return ('User cannot post multiple reviews for the same item');
    }
    return false;
    
}