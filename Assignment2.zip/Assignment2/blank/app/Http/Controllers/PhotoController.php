<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Album;
use App\Artist;
use App\Review;
use App\Photo;
use App\Recommend;
use Auth;

class PhotoController extends Controller
{
    public function __construct() {
         $this->middleware('auth');
         //restrict the access
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        //
        return view('albums.create_photo_form')->with('album_id', $id);
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request, [
            'image' => 'required',
            'album_id' => 'required',
            'user_id' => 'required',
        ]);
        $image_store = request()->file('image')->store('albums_photos', 'public');
        $photo = new Photo();
        $photo->image = $image_store;
        $photo->album_id = $request->album_id;
        $photo->user_id = $request->user_id;
        $photo->save();
        //store an image
        if (Auth::user()) {
            $recommend = new Recommend();
            $recommend->user_id = $request->user_id;
            $album = Album::find($request->album_id);
            $recommend->keyword = $album->genre;
            $recommend->save(); 
        }
        //check to see if there is needed to add a recommendation
        
        return redirect("/album/$photo->album_id");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($album_id, $photo_id)
    {
        //
        $photo = Photo::find($photo_id);
        $photo->delete();
        $album = Album::find($album_id);
        $photos = Photo::where('album_id', '=', $album_id)->get();
        $reviews = Review::where('album_id', '=', $album_id)->orderBy('updated_at', 'desc')->paginate(5);
        return view('albums.show')->with('album', $album)->with('reviews', $reviews)->with('photos', $photos);
        //delete a photo
    }
}
