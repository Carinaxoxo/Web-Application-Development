<?php $__env->startSection('title'); ?>
    Albums
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul>
    <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/album/<?php echo e($album->id); ?>"><li><?php echo e($album->name); ?></li></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
    <br>
    <a href="/album/create">Create a new album</a>
    <br><br><br>
    <a href="/document">Documentation</a>
    <br>
    <a href="/erd">ERDiagram</a>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>