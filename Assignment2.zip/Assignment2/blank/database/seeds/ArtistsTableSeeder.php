<?php

use Illuminate\Database\Seeder;

class ArtistsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('artists')->insert([
        'artist' => 'Arian Grande',
        ]);
        DB::table('artists')->insert([
        'artist' => 'Avril Lavigne',
        ]);
        DB::table('artists')->insert([
        'artist' => 'Eminem',
        ]);
        DB::table('artists')->insert([
        'artist' => 'Logic',
        ]);
        DB::table('artists')->insert([
        'artist' => 'J.Cole',
        ]);
        DB::table('artists')->insert([
        'artist' => 'Drake',
        ]);
        DB::table('artists')->insert([
        'artist' => 'A$ap Rock',
        ]);
        DB::table('artists')->insert([
        'artist' => 'Lily Allen',
        ]);
        DB::table('artists')->insert([
        'artist' => 'The Carters',
        ]);
        DB::table('artists')->insert([
        'artist' => '88 Rising',
        ]);
    }
}
