<?php

use Illuminate\Database\Seeder;

class RecommendsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('recommends')->insert([
        'user_id' => '1',
        'keyword' => 'Trap',
        ]);
        DB::table('recommends')->insert([
        'user_id' => '2',
        'keyword' => 'Conscious rap',
        ]);
        DB::table('recommends')->insert([
        'user_id' => '3',
        'keyword' => 'Hip hop',
        ]);
        DB::table('recommends')->insert([
        'user_id' => '4',
        'keyword' => 'Rock',
        ]);
        DB::table('recommends')->insert([
        'user_id' => '5',
        'keyword' => 'Conscious rap',
        ]);
    }
}
