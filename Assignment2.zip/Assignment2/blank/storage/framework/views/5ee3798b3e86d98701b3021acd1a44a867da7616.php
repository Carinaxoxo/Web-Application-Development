<?php $__env->startSection('title'); ?>
  ER Diagram
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>ER Diagram</h1>
  <div id="erd"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>