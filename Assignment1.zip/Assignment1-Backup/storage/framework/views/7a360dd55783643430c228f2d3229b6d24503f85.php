<?php $__env->startSection('title'); ?>
  Update Album
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Update Album</h1>
    <form method="post" action="/update_album_action" class="form">
    <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" value="<?php echo e($album->id); ?>">
        <p>
        <label>Album Name: </label>
        <input type="text" name="name" value="<?php echo e($album->name); ?>">
        </p>
        <p>
        <label>Aritist: </label>
        <input type="text" name="artist" value="<?php echo e($album->artist); ?>">
        </p>
        <p>
        <label>Publish Date: </label>
        <input type="text" name="pdate" value="<?php echo e($album->pdate); ?>">
        </p>
        <p>
        <label>Genre: </label>
        <input type="text" name="genre" value="<?php echo e($album->genre); ?>">
        </p>
        <input type="submit" value="Update item">
    </form>
    <br>
    <?php if(!empty($eMessage)): ?>
      <?php echo e($eMessage); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>