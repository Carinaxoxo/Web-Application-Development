@extends('layouts.master')

@section('title')
  Adding review form
@endsection

@section('content')
        <h1>Add Review</h1>
        <form method="post" action="/add_review_action" class="form">
            {{csrf_field()}}
            <p>
              <label>User Name:</label>
              <input type="text" name="username">
            </p>
            <p>
              <label>Date:</label>
              <input type="text" name="rdate">
            </p>
            <p>
              <label>Review:</label>
              <input type="text" name="review">
            </p>
            <p>
              <label>Rating:</label>
              <input type="text" name="rating">
            </p>
            <p>
              <label>Album Name:</label>
              <input type="text" name="albumname">
            </p>
            <input type="submit" value="Submit">
      </form>
      <br>
  @if (!empty($eMessage))
    <p style="background-color:Tomato; width: 20%; padding: 15px 30px;">{{$eMessage}}</p>
  @endif
@endsection