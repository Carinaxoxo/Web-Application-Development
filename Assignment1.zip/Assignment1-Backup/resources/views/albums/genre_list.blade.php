@extends('layouts.master')

@section('title')
  Welcome to the music world - Genres
@endsection

@section('content')
  <h1>Genres list</h1>
  @if($genres)
    @foreach($genres as $genre)
      <br>
      <div class="genre">
          <p><a href="{{url("genre_album/$genre->genre")}}">{{$genre->genre}}</a></p>
      </div>
      <br>
    @endforeach
  @endif
@endsection