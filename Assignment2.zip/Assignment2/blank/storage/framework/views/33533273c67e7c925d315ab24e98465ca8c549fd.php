<?php $__env->startSection('title'); ?>
    Album
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="album">
        <label>Album Name:</label><h1><?php echo e($album->name); ?></h1>
        <label>Aritist:</label><p><?php echo e($album->artist->artist); ?></p>
        <label>Publish Date:</label><p><?php echo e($album->pdate); ?></p>
        <label>Genre: </label><p><?php echo e($album->genre); ?></p>
        <label>Description : </label><p><?php echo e($album->description); ?></p>
        
        <?php if(Auth::user() && Auth::user()->role == 'moderator'): ?>
        <p><a href="/album/<?php echo e($album->id); ?>/edit">Edit</a></p>
        <p>
            <form method="POST" action="/album/<?php echo e($album->id); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <input type="submit" value="Delete">
            </form>
        </p>
        <?php endif; ?>
    </div>
    
    
    <br>
    <br>
    
    <?php if(count($photos) > 0): ?>
        <label>Album photos: </label>
        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="photo">
                <img src="<?php echo e(url($photo->image)); ?>" alt="album image"style="width:300px;height:300px;">
                <br>
                <?php if($photo->user_id == 0): ?>
                    <label>Default Image</label>
                <?php else: ?>
                    <label>Upload User: <?php echo e($photo->user->first_name); ?> <?php echo e($photo->user->last_name); ?></label>
                <?php endif; ?>
                <?php if(Auth::user() && (Auth::user()->role == 'moderator' || Auth::user()->id == $photo->user_id)): ?>
                    <p>
                        <form method="POST" action="/album/<?php echo e($album->id); ?>/photo/<?php echo e($photo->id); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" value="Delete">
                        </form>
                    </p>
                <?php endif; ?>
                <br>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <?php if(Auth::user()): ?>
        <a href="/album/<?php echo e($album->id); ?>/photo/create">Upload a new photo</a>
        <br>
    <?php endif; ?>
    <br>
    <br>
    
    <?php if(count($reviews) > 0): ?>
        <p><a href="/album/<?php echo e($album->id); ?>/orderby">List reviews by rating</a></p>
        <p><a href="/album/<?php echo e($album->id); ?>">List reviews by date</a></p>
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($review->like > $review->dislike): ?>
              <div class="popular">
                <a href="/user/<?php echo e($review->user_id); ?>"><label>User: <?php echo e($review->user->first_name); ?> <?php echo e($review->user->last_name); ?></label></a>
                <?php if(Auth::user() && Auth::user()->id != $review->user_id): ?>
                    <a href="/album/<?php echo e($album->id); ?>/user/<?php echo e($review->user_id); ?>/follow">
                       <input type="button" value="Follow" />
                    </a>
                    <a href="/album/<?php echo e($album->id); ?>/user/<?php echo e($review->user_id); ?>/unfollow">
                       <input type="button" value="Unfollow" />
                    </a>
                <?php endif; ?>
                <br>
                <br>
                <label>Review: </label><p><?php echo e($review->review); ?></p>
                <label>Rating: <?php echo e($review->rating); ?></label>
                <br>
                <br>
                <label>Publish Date: <?php echo e($review->created_at); ?>    Edit Date: <?php echo e($review->updated_at); ?></label>
                <div class="like">
                    <a href="/album/<?php echo e($review->album_id); ?>/review/<?php echo e($review->id); ?>/like">
                       <input type="button" value="Like" />
                    </a><p><?php echo e($review->like); ?></p>
                    <a href="/album/<?php echo e($review->album_id); ?>/review/<?php echo e($review->id); ?>/dislike">
                       <input type="button" value="Dislike" />
                    </a><p><?php echo e($review->dislike); ?></p>
                </div>
                <?php if(Auth::user() && (Auth::user()->role == 'moderator' || Auth::user()->id == $review->user_id)): ?>
                    <p><a href="/album/<?php echo e($album->id); ?>/review/<?php echo e($review->id); ?>/edit">Edit</a></p>
                    <p>
                        <form method="POST" action="/album/<?php echo e($album->id); ?>/review/<?php echo e($review->id); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" value="Delete">
                        </form>
                    </p>
                <?php endif; ?>
            </div>
          <?php else: ?>
              <div class="review">
                <a href="/user/<?php echo e($review->user_id); ?>"><label>User: <?php echo e($review->user->first_name); ?> <?php echo e($review->user->last_name); ?></label></a>
                <?php if(Auth::user() && Auth::user()->id != $review->user_id): ?>
                    <a href="/album/<?php echo e($album->id); ?>/user/<?php echo e($review->user_id); ?>/follow">
                       <input type="button" value="Follow" />
                    </a>
                    <a href="/album/<?php echo e($album->id); ?>/user/<?php echo e($review->user_id); ?>/unfollow">
                       <input type="button" value="Unfollow" />
                    </a>
                <?php endif; ?>
                <br>
                <br>
                <label>Review: </label><p><?php echo e($review->review); ?></p>
                <label>Rating: <?php echo e($review->rating); ?></label>
                <br>
                <br>
                <label>Publish Date: <?php echo e($review->created_at); ?>    Edit Date: <?php echo e($review->updated_at); ?></label>
                <div class="like">
                    <a href="/album/<?php echo e($review->album_id); ?>/review/<?php echo e($review->id); ?>/like">
                       <input type="button" value="Like" />
                    </a><p><?php echo e($review->like); ?></p>
                    <a href="/album/<?php echo e($review->album_id); ?>/review/<?php echo e($review->id); ?>/dislike">
                       <input type="button" value="Dislike" />
                    </a><p><?php echo e($review->dislike); ?></p>
                </div>
                <?php if(Auth::user() && (Auth::user()->role == 'moderator' || Auth::user()->id == $review->user_id)): ?>
                    <p><a href="/album/<?php echo e($album->id); ?>/review/<?php echo e($review->id); ?>/edit">Edit</a></p>
                    <p>
                        <form method="POST" action="/album/<?php echo e($album->id); ?>/review/<?php echo e($review->id); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" value="Delete">
                        </form>
                    </p>
                <?php endif; ?>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
    <?php echo e($reviews->links()); ?>

    
    <?php if(Auth::user()): ?>
        <a href="/album/<?php echo e($album->id); ?>/review/create">Create a new review</a>
        <br>
    <?php endif; ?>
    
    <a href="/album">Index</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>