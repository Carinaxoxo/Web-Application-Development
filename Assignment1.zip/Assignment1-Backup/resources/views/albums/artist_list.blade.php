@extends('layouts.master')

@section('title')
  Welcome to the music world - Artists
@endsection

@section('content')
  <h1>Artists list</h1>
  @if($artists)
    @foreach($artists as $artist)
      <br>
      <div class="artist">
          <p><a href="{{url("artist_album/$artist->artist")}}">{{$artist->artist}}</a></p>
      </div>
      <br>
    @endforeach
  @endif
@endsection