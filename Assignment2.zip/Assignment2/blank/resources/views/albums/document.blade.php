@extends('layouts.app')

@section('title')
  Document
@endsection

@section('content')
   <h1>Document</h1>
   <p>
       <h3>1. What were able to complete</h3>
       <p>
           Completed all basic functions.
       </p><br>

       <h3>2. What were not able to complete</h3>
       <p>
           User cannot jump back to the previous page after login.
       </p><br>
       
       <h3>3. Any interesting approaches you took</h3>
       <p>
           Sorting reviews is done by using a new path. The like function and follow function are also done by using different paths.
       </p><br>
       
       <h3>4. Any extra that was implemented</h3>
       <p>
          When the user dislikes a comment, his previous like record will be deleted, and vice versa. 
       </p><br>
       <h3>5. If you have implemented the recommendation feature, briefly describe the algorithm you've used to determine what recommendation to make.</h3>
       <p>
            I didn't use an algorithm, I chose another simpler method. 
            When the user makes a review, uploads a photo, and creates an album, a record is generated in the recommends table, 
            which includes the current user's id and album genre as the keyword. 
            In the user's personal information page, based on the keyword search, the latest album released in the relevant style album is recommended.
       </p><br>

   </p>
@endsection