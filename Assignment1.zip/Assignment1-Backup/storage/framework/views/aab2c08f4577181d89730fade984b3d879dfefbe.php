<?php $__env->startSection('title'); ?>
  Welcome to the music world - Genres
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1>Genres list</h1>
  <?php if($genres): ?>
    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <br>
      <div class="genre">
          <p><a href="<?php echo e(url("genre_album/$genre->genre")); ?>"><?php echo e($genre->genre); ?></a></p>
      </div>
      <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>