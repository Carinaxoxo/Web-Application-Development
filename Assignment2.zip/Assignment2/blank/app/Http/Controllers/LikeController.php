<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Album;
use App\Artist;
use App\Review;
use App\Photo;
use Auth;

class LikeController extends Controller
{
    public function __construct() {
         $this->middleware('auth', ['except'=>['show']]);
         //restrict the access
    }
}
