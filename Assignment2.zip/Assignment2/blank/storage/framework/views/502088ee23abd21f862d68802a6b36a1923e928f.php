<?php $__env->startSection('title'); ?>
    Album
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Create a new Album</h1>
    <?php if(count($errors) > 0): ?>
      <div class="alert">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <form method="POST" action="/album">
    <?php echo e(csrf_field()); ?>

        <p><label>Name: </label><input type="text" name="name" value="<?php echo e(old('name')); ?>"></p>
        <p>
            <label>Artist: </label>
            <select name="artist">
            <?php $__currentLoopData = $artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($artist->id); ?>"><?php echo e($artist->artist); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </p>
        <p><label>Pulish Date: </label><input type="date" name="pdate" value="<?php echo e(old('pdate')); ?>"></p>
        <p><label>Genre: </label><input type="text" name="genre" value="<?php echo e(old('genre')); ?>"></p>
        <input type="submit" value="Create"> 
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>