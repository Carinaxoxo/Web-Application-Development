<?php $__env->startSection('title'); ?>
  Document
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <h1>Document</h1>
   <p>
       <h3>1. What were able to complete</h3>
       <p>
           The main elements of all pages inherit the same page, the banner and the navbar appear on all pages in the same way. 
           The first main page is home, which is used to show the latest release of the album. 
           The second main page is a list of albums, and a brief description of the specific album will be displayed along with the album. 
           The third main page is the artist list, and the names of all the singers will be displayed. 
           Click on the artist name to view a short summary of every album released by this artist. 
           The third main page is a list of genres, and the names of all the genres are displayed. 
           Click on the genre name to browse a short summary of all the albums of this style. 
           The content of the fourth main page is to display the album according to the number of reviews. 
           The more comments, the higher the ranking. 
           The content of the fifth main page is to display the album according to the rating, the higher the average score, the higher the ranking. 
           Users can manually add new albums or update existing albums. When adding a new album, all information must be filled, and an artist cannot have two albums of the same name. 
           Users can comment on all albums, but they can't comment on the same album a second time. 
           Comments can be updated. When rating, the rating score must be a floating-point number between one and five. 
           There are two links in the Navbar that connect the ER Diagram and the document.
       </p><br>

       <h3>2. What were not able to complete</h3>
       <p>
           It is too much trouble to make input validation when updating albums and comments. 
           The page jump seems to have a problem after updating the review.
       </p><br>
       
       <h3>3. Any interesting approaches you took</h3>
       <p>
           The banner is a picture used, with a layer of color on it, the effect is very good.
           When writing the rating list, connect the review table and the album table, then I will select all the comments related to this album when displaying the details of the album. 
           In order to make the comments not empty, so that the data can be called up, I choose to automatically fill in other information with the null value when adding a new album. 
           However, this album will then have one comment with no real content. I will divide the albums into two classes according to whether the comment content is empty. 
           Some comments were selected by counting the number of comments in the SQL statement, then other comments without real content will be selected while decreasing the number of comments by one, then it is zero.
           When displaying the number of comments on the album detail page, the number is queried separately. 
           If the comment content is not empty, the total number of comments is counted, thus avoiding invalid comments that automatically inserted with null values.
           When writing input validation, it feels easier to write verification for two add actions than the updates.
       </p><br>
       
       <h3>4. Any extra that was implemented</h3>
       <p>
          Comments can be deleted. 
          Add a homepage instead of using the album list to do the homepage because I have obsessive-compulsive disorder. 
       </p><br>

   </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>