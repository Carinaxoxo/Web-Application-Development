<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Album;
use App\Artist;
use App\Review;
use App\Photo;
use App\Like;
use App\Follow;
use App\Recommend;
use Auth;
use App\User;

class AlbumController extends Controller
{
    public function __construct() {
         $this->middleware('auth', ['only'=>['edit', 'destroy']]);
         //restrict the access
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $albums = Album::all();
        return view('albums.index')->with('albums', $albums);
        //list all albums' names
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $genres = Album::all();
        return view('albums.create_album_form')->with('artists', Artist::all());
        //create a album
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        
        $this->validate($request, [
            'name' => 'required|max:255|unique:albums,name',
            'genre' => 'required',
            'pdate' => 'required',
            'artist' => 'required',
            'description' => 'required|string|max:1000'
        ]);
        $album = new Album();
        $album->name = $request->name;
        
        if (Artist::where('artist', '=', $request->artist)->exists()) {
            $artist = Artist::where('artist', '=', $request->artist)->get();
            $album->artist_id = $artist[0]->id;
        } else {
            $artist = new Artist();
            $artist->artist = $request->artist;
            $artist->save();
            $album->artist_id = $artist->id;
        }//to ee if the artist is existed
        $album->pdate = $request->pdate;
        $album->genre = $request->genre;
        $album->description = $request->description;
        $album->save();
        
        $photo = new Photo();
        $photo->album_id = $album->id;
        $photo->user_id = 0;
        $photo->image = 'albums_photos/default.png';
        $photo->save();
        //add a default photo
        
        if (Auth::user()) {
            $recommend = new Recommend();
            $recommend->user_id = Auth::user()->id;
            $recommend->keyword = $album->genre;
            $recommend->save();
        }
        //check if there is needed to create a recommend
        
        return redirect("/album/$album->id");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $album = Album::find($id);
        $photos = Photo::where('album_id', '=', $id)->get();
        $reviews = Review::where('album_id', '=', $id)->orderBy('updated_at', 'desc')->paginate(5);
        return view('albums.show')->with('album', $album)->with('reviews', $reviews)->with('photos', $photos);
        //list details and list reviews by date by default
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $album = Album::find($id);
        $genres = Album::distinct()->select('genre')->get();
        $artists = Artist::distinct()->select('artist', 'id')->get();
        return view('albums.edit_album_form')->with('album', $album)->with('artists', $artists)->with('genres', $genres);
        //return a create form
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, [
            'name' => 'required|max:255',
            'genre' => 'required',
            'pdate' => 'required',
            'artists' => 'exists:artists,id'
        ]);
        $album = Album::find($id);
        $album->name = $request->name;
        $album->artist_id = $request->artist_id;
        $album->pdate = $request->pdate;
        $album->genre = $request->genre;
        $album->save();
        return redirect("/album/$album->id");
        //update information 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $album = Album::find($id);
        $album->delete();
        $albums = Album::all();
        return view('albums.index')->with('albums', $albums);
        //delete a album
    }
}
