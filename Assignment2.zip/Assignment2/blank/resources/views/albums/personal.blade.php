@extends('layouts.app')

@section('title')
    {{$user->first_name}} {{$user->last_name}}
@endsection

@section('content')
    <label>User Name:</label><h1>{{$user->first_name}} {{$user->last_name}}</h1>
    <div class="following">
        <label>Following: </label>
        @if (!empty($followings) && count($followings) > 0)
            @foreach ($followings as $following)
                <p>{{$following->first_name}} {{$following->last_name}}</p>
            @endforeach
        @elseif (empty($followings))
            <p>No following</p>
        @endif
    </div>
    <div class="follower">
        <label>Followers: </label>
        @if (!empty($followers) && count($followers) > 0)
            @foreach ($followers as $follower)
                <p>{{$follower->first_name}} {{$follower->last_name}}</p>
            @endforeach
        @elseif (empty($followers))
            <p>No follower</p>
        @endif
    </div>
    
    <br>
    <br>
    
    <label>Reviews posted by {{$user->first_name}} {{$user->last_name}}: </label>
    @if (!empty($reviews) && count($reviews) > 0)
        @foreach($reviews as $review)
            <div class="review">
                <label>Album: </label><p>{{$review->album->name}}</p>
                <label>Review: </label><p>{{$review->review}}</p>
                <label>Rating: {{$review->rating}}</label>
                <br>
                <br>
                <label>Publish Date: {{$review->created_at}}    Edit Date: {{$review->updated_at}}</label>
                <div class="like">
                    <a href="/album/{{$review->album_id}}/review/{{$review->id}}/like">
                       <input type="button" value="Like" />
                    </a><p>{{$review->like}}</p>
                    <a href="/album/{{$review->album_id}}/review/{{$review->id}}/dislike">
                       <input type="button" value="Dislike" />
                    </a><p>{{$review->dislike}}</p>
                </div>
            </div>
        @endforeach
    @elseif (empty($reviews))
        <p>{{$user->first_name}} {{$user->last_name}} has posted no reviews</p>
    @endif
    
    @if (!empty($albums) && count($albums) > 0)
        <label>Albums {{$user->first_name}} {{$user->last_name}} may like: </label>
        <br>
        @foreach($albums as $album)
            <div class="recommend">
                <a href="/album/{{$album->id}}"><label>Album Name:</label><h1>{{$album->name}}</h1></a>
                <label>Artist:</label><p>{{$album->artist->artist}}</p>
                <label>Publish Date:</label><p>{{$album->pdate}}</p>
                <label>Genre: </label><p>{{$album->genre}}</p>
            </div>
        @endforeach
    @elseif (empty($albums))
        <label>No recommendation</label>
    @endif
    
@endsection