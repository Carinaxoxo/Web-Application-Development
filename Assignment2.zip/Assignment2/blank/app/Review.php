<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    //
    function user() {
        return $this->belongsTo('App\User');
    }
    
    function album() {
        return $this->belongsTo('App\Album');
    }
    
    function like() {
        return $this->hasMany('App\Like');
    }
    
    // function like($id, $user_id) {
    //     $review = Review::find($id);
    //     $like = $review->like;
    //     $review->like = $like + 1;
        
    //     DB::table('likes')->insert([
    //     'review_id' => $id,
    //     'user_id' => $user_id,
    //     'vote' => 'like',
    //     ]);
        
    //     $album_id = $review->album_id;
    //     redirect("/album/$album_id");
    // }
    
    // function dislike($id, $user_id) {
    //     $review = Review::find($id);
    //     $dislike = $review->dislike;
    //     $review->dislike = $dislike + 1;
        
    //     DB::table('likes')->insert([
    //     'review_id' => $id,
    //     'user_id' => $user_id,
    //     'vote' => 'dislike',
    //     ]);
        
    //     $album_id = $review->album_id;
    //     redirect("/album/$album_id");
}
