@extends('layouts.master')

@section('title')
  Album
@endsection
  
@section('content')
      <div class="album">
          <p>Album Name: {{$album->name}}</p>
          <p>Artist: <a href="{{url("artist_album/$album->artist")}}">{{$album->artist}}</a></p>
          <p>Publish Date: {{$album->pdate}}</p>
          <p>Genre: <a href="{{url("genre_album/$album->genre")}}">{{$album->genre}}</a></p>
      </div>
      <br>
      <br>
      <br>
      <p class="reviewnumber">The number of reviews: {{$number}}</p>
        @if(!empty($reviews))
          @foreach($reviews as $review)
            @if(!empty($review->review))
            <div class="review">
                <p>User Name: {{$review->username}}</p>
                <p>Review: {{$review->review}}</p>
                <p>Date: {{$review->rdate}}</p>
                <p>Rating: {{$review->rating}}</p>
                <a href="{{url("update_review/$review->review_id")}}"> Update this review</a> <br>
                <a href="{{url("delete_review/$review->review_id")}}"> Delete this review</a>
            </div>
            <br>
            @endif
          @endforeach
        @endif
<p><a href="{{url("add_review")}}">Add an review</a></p>
<p><a href="{{url("update_album/$album->album_id")}}"> Update album </a></p>
<p><a href="{{url("delete_album/$album->album_id")}}"> Delete album </a></p>
<p><a href="/"> Home </a></p>
@endsection