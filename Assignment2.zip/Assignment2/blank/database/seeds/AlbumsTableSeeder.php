<?php

use Illuminate\Database\Seeder;

class AlbumsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('albums')->insert([
        'name' => 'Sweetener',
        'artist_id' => '1',
        'pdate' => '2018-08-17',
        'genre' => 'Trap',
        'description' => 'Sweetener is the fourth studio album by American singer Ariana Grande. 
                          It was released on August 17, 2018, through Republic Records.
                          The album is the follow-up to her 2016 studio album Dangerous Woman, 
                          and features guest appearances from Pharrell Williams, Nicki Minaj and Missy Elliott.',
        ]);
        DB::table('albums')->insert([
        'name' => 'Head Above Water',
        'artist_id' => '2',
        'pdate' => '2018-09-20',
        'genre' => 'Rock',
        'description' => 'Head Above Water is a song by Canadian singer-songwriter Avril Lavigne from her upcoming sixth studio album (2018). 
                          It was written by Lavigne, Stephan Moccio, and Travis Clark; while being produced by Moccio. 
                          It was released as the lead single from the album on September 19, 2018, by BMG.',
        ]);
        DB::table('albums')->insert([
        'name' => 'Kamikaze',
        'artist_id' => '3',
        'pdate' => '2018-08-31',
        'genre' => 'Hip hop',
        'description' => 'Kamikaze is the tenth studio album by American rapper Eminem. Previously unannounced, 
                          the album was released on August 31, 2018 by Aftermath Entertainment, Interscope Records, and Shady Records.',
        ]);
        DB::table('albums')->insert([
        'name' => 'YSIV',
        'artist_id' => '4',
        'pdate' => '2018-09-28',
        'genre' => 'Conscious rap',
        'description' => 'YSIV (an abbreviation of Young Sinatra IV) is Logic’s fourth studio album and the fourth (and final) entry in the Young Sinatra series. 
                          It is separate from his previously announced album Ultra 85. The album was released on September 28, 2018.',
        ]);
        DB::table('albums')->insert([
        'name' => 'KOD',
        'artist_id' => '5',
        'pdate' => '2018-04-20',
        'genre' => 'Conscious rap',
        'description' => 'KOD (an initialism for Kids on Drugs, King Overdosed and Kill Our Demons) is the fifth studio album by American rapper J. Cole.',
        ]);
        DB::table('albums')->insert([
        'name' => 'Views',
        'artist_id' => '6',
        'pdate' => '2016-04-29',
        'genre' => 'Hip hop',
        'description' => 'NO',
        ]);
        DB::table('albums')->insert([
        'name' => 'Testing',
        'artist_id' => '7',
        'pdate' => '2018-05-25',
        'genre' => 'Hip hop',
        'description' => 'NO',
        ]);
        DB::table('albums')->insert([
        'name' => 'No shame',
        'artist_id' => '8',
        'pdate' => '2018-06-08',
        'genre' => 'Electropop',
        'description' => 'NO',
        ]);
        DB::table('albums')->insert([
        'name' => 'Everything is love',
        'artist_id' => '9',
        'pdate' => '2018-06-16',
        'genre' => 'Hip hop',
        'description' => 'NO',
        ]);
        DB::table('albums')->insert([
        'name' => 'Head In The Clouds',
        'artist_id' => '10',
        'pdate' => '2018-07-20',
        'genre' => 'Trap',
        'description' => 'NO',
        ]);
    }
}
