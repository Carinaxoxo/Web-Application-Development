@extends('layouts.master')

@section('title')
  ER Diagram
@endsection

@section('content')
  <h1>ER Diagram</h1>
  <div id="erd"></div>
@endsection