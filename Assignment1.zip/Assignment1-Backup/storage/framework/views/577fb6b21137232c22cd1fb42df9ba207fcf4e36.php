<?php $__env->startSection('title'); ?>
  Welcome to the music world - Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div id="HomeBody">
      <h1 style="float: left;">WHAT'S NEW!</h1>
      <div id = "newcover"></div>
  </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>