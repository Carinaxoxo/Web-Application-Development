<?php $__env->startSection('title'); ?>
    <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <label>User Name:</label><h1><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h1>
    <div class="following">
        <label>Following: </label>
        <?php if(!empty($followings) && count($followings) > 0): ?>
            <?php $__currentLoopData = $followings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $following): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($following->first_name); ?> <?php echo e($following->last_name); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(empty($followings)): ?>
            <p>No following</p>
        <?php endif; ?>
    </div>
    <div class="follower">
        <label>Followers: </label>
        <?php if(!empty($followers) && count($followers) > 0): ?>
            <?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($follower->first_name); ?> <?php echo e($follower->last_name); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(empty($followers)): ?>
            <p>No follower</p>
        <?php endif; ?>
    </div>
    
    <br>
    <br>
    
    <label>Reviews posted by <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>: </label>
    <?php if(!empty($reviews) && count($reviews) > 0): ?>
        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="review">
                <label>Album: </label><p><?php echo e($review->album->name); ?></p>
                <label>Review: </label><p><?php echo e($review->review); ?></p>
                <label>Rating: <?php echo e($review->rating); ?></label>
                <br>
                <br>
                <label>Publish Date: <?php echo e($review->created_at); ?>    Edit Date: <?php echo e($review->updated_at); ?></label>
                <div class="like">
                    <a href="/album/<?php echo e($review->album_id); ?>/review/<?php echo e($review->id); ?>/like">
                       <input type="button" value="Like" />
                    </a><p><?php echo e($review->like); ?></p>
                    <a href="/album/<?php echo e($review->album_id); ?>/review/<?php echo e($review->id); ?>/dislike">
                       <input type="button" value="Dislike" />
                    </a><p><?php echo e($review->dislike); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php elseif(empty($reviews)): ?>
        <p><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> has posted no reviews</p>
    <?php endif; ?>
    
    <?php if(!empty($albums) && count($albums) > 0): ?>
        <label>Albums <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> may like: </label>
        <br>
        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="recommend">
                <a href="/album/<?php echo e($album->id); ?>"><label>Album Name:</label><h1><?php echo e($album->name); ?></h1></a>
                <label>Artist:</label><p><?php echo e($album->artist->artist); ?></p>
                <label>Publish Date:</label><p><?php echo e($album->pdate); ?></p>
                <label>Genre: </label><p><?php echo e($album->genre); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php elseif(empty($albums)): ?>
        <label>No recommendation</label>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>