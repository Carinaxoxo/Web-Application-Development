<?php $__env->startSection('title'); ?>
  Updating review form
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <h1>Update Review</h1>
      <form method="post" action="/update_review_action" class="form">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e($review->id); ?>">
            <p>
              <label>Date:</label>
              <input type="text" name="rdate" value="<?php echo e($review->rdate); ?>">
            </p>
            <p>
              <label>Review:</label>
              <input type="text" name="review" value="<?php echo e($review->review); ?>">
            </p>
            <p>
              <label>Rating:</label>
              <input type="text" name="rating" value="<?php echo e($review->rating); ?>">
            </p>
            <input type="submit" value="Submit">
      </form>
      <br>
  <?php if(!empty($eMessage)): ?>
    <p style="background-color:Tomato; width: 20%; padding: 15px 30px;"><?php echo e($eMessage); ?></p>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>