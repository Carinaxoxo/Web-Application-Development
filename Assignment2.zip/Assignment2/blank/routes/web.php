<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Album;
use App\User;
use App\Artist;
use App\Review;
use App\Photo;
use App\Like;
use App\Follow;
use App\Recommend;

Route::get('/', function () {
    return view('welcome');
});

Route::resource('album', 'AlbumController');
Route::resource('artist', 'ArtistsController');
Route::resource('album/{id}/review', 'ReviewController');
Route::resource('album/{id}/photo', 'PhotoController');

Route::get('document', function() {
    return view('albums.document');
});

Route::get('erd', function() {
    return view('albums.erd');
});

Route::get('album/{album_id}/review/{review_id}/{vote}', function ($album_id, $review_id, $vote) {
    if (Auth::user()) {
        if (Like::whereRaw('review_id = ? and user_id = ? and vote = ?', array($review_id, Auth::user()->id, $vote))->exists()) {
            if ($vote == 'like') {
                $error = 'liked';
            } else if ($vote == 'dislike') {
                $error = 'disliked';
            }
            return view('albums.forbid')->with('error', $error);
            //make sure you have not like twice or dislike twice
        } else {
            $like = new Like();
            $like->review_id = $review_id;
            $like->user_id = Auth::user()->id;
            $like->vote = $vote;
            $like->save();
            $review = Review::where('id', '=', $review_id)->get();
            $review_like = $review[0]->like;
            $review_dislike = $review[0]->dislike;
            if ($vote == 'like') {
                if (Like::whereRaw('review_id = ? and user_id = ? and vote = ?', array($review_id, Auth::user()->id, 'dislike'))->exists()) {
                    $cancel = Like::whereRaw('review_id = ? and user_id = ? and vote = ?', array($review_id, Auth::user()->id, 'dislike'))->get();
                    $cancel[0]->delete();
                    $review[0]->dislike = $review_dislike - 1;
                }
                $review[0]->like = $review_like + 1;
                //add a like
            }
            if ($vote == 'dislike') {
                if (Like::whereRaw('review_id = ? and user_id = ? and vote = ?', array($review_id, Auth::user()->id, 'like'))->exists()) {
                    $cancel = Like::whereRaw('review_id = ? and user_id = ? and vote = ?', array($review_id, Auth::user()->id, 'like'))->get();
                    $cancel[0]->delete();
                    $review[0]->like = $review_like - 1;
                }
                $review[0]->dislike = $review_dislike + 1;
                //add a dislike
            }
            $review[0]->save();
            return redirect("/album/$album_id");
        }
    } else {
        return redirect("/login");
    }
});

Route::get('album/{album_id}/user/{user_id}/{action}', function ($album_id, $user_id, $action) {
    if (Auth::user()) {
            if ($action == 'follow') {
                if(Follow::whereRaw('follower_id = ? and user_id = ?', array(Auth::user()->id, $user_id))->exists()) {
                    $error = 'followed';
                }
            }elseif ($action == 'unfollow') {
                if(Follow::whereRaw('follower_id = ? and user_id = ?', array(Auth::user()->id, $user_id))->exists() == false) {
                    $error = 'unfollowed';
                }
            }
            if (!empty($error)) {
                    return view('albums.forbid')->with('error', $error);
            } 
            //make sure you have not follow twice or unfollow twice
            else {
                if ($action == 'follow') {
                    $follow = new Follow();
                    $follow->user_id = $user_id;
                    $follow->follower_id = Auth::user()->id;
                    $follow->save();
                    return redirect("/album/$album_id");
                    //add a follow
                }
                if ($action == 'unfollow') {
                    $follower_id = Auth::user()->id;
                    $unfollow = Follow::whereRaw('user_id = ? and follower_id = ?', array($user_id, $follower_id))->get();
                    $follow_delete = Follow::find($unfollow[0]->id);
                    $follow_delete->delete();
                    return redirect("/album/$album_id");
                    //delete the follow
                }
            }
    } else {
        return redirect("/login");
    }

});

Route::get('/album/create', function () {
    $artists = Artist::all();
    return view('albums.create_album_form')->with('artists', $artists);
    //create a album
});

Route::get('/album/{id}/orderby', function ($id) {
    $album = Album::find($id);
    $photos = Photo::where('album_id', '=', $id)->get();
    $reviews = Review::where('album_id', '=', $id)->orderBy('rating', 'desc')->paginate(5);
    return view('albums.show')->with('album', $album)->with('reviews', $reviews)->with('photos', $photos);
    //list reviews by rating
});

Route::get('/user/{id}', function ($id) {
    $user = User::find($id);
    $fings = Follow::where('follower_id', '=', $id)->get();
    if (Follow::where('follower_id', '=', $id)->exists()) {
        for ($i=0; $i<count($fings); $i++) {
        $followings[$i] = User::find($fings[$i]->user_id);
        }
    } else {
        $followings = null;
    }// get the following users and if no following then return empty
    $fers = Follow::where('user_id', '=', $id)->get();
    if (Follow::where('user_id', '=', $id)->exists()) {
        for ($n=0; $n<count($fers); $n++) {
        $followers[$n] = User::find($fers[$n]->follower_id);
        }
    }else {
        $followers = null;
    }// get the follower users and if no follower then return empty
    if (Review::where('user_id', '=', $id)->exists()) {
        $reviews = Review::where('user_id', '=', $id)->get();
    } else {
        $reviews = null;
    }// get the reviews and if no reviews then return empty
    if (Recommend::where('user_id', '=', $id)->exists()) {
        $keywords = Recommend::where('user_id', '=', $id)->distinct()->get(['keyword']);
        for ($i=0; $i<count($keywords); $i++) {
        $albums[$i] = Album::where('genre', '=', $keywords[$i]->keyword)->orderBy('pdate', 'desc')->first();
        }
    } else {
        $albums = null;
    }// get the recommendations and if no recommendation then return empty
    return view('albums.personal')->with('user', $user)->with('followings', $followings)->with('followers', $followers)->with('reviews', $reviews)->with('albums', $albums);
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
