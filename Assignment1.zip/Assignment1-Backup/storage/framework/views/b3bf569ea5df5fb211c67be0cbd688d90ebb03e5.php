<?php $__env->startSection('title'); ?>
  Welcome to the music world - Genres
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1><?php echo e($albums[0]->genre); ?></h1>
  <?php if($albums): ?>
    <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <br>
      <div class="album">
          <p>Album Name: <a href="<?php echo e(url("album_detail/$album->id")); ?>"><?php echo e($album -> name); ?></a></p>
          <p>Artist: <a href="<?php echo e(url("artist_album/$album->artist")); ?>"><?php echo e($album -> artist); ?></a></p>
          <p>Publish Date: <?php echo e($album -> pdate); ?></p>
          <p>Genre: <a href="<?php echo e(url("genre_album/$album->genre")); ?>"></a><?php echo e($album -> genre); ?></p>
      </div>
      <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>