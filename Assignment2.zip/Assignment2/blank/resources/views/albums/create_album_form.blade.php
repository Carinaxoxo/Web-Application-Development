@extends('layouts.app')

@section('title')
    Album
@endsection

@section('content')
    <h1>Create a new Album</h1>
    @if (count($errors) > 0)
      <div class="alert">
          <ul>
              @foreach ($errors->all() as $error)
                <li>{{$error}}</li>
              @endforeach
          </ul>
      </div>
    @endif
    <div class="form">
        <form method="POST" action="/album">
            {{csrf_field()}}
            <p><label>Name: </label><input type="text" name="name" value="{{old('name')}}"></p>
            <p><label>Artist: </label><input type="text" name="artist" value="{{old('artist')}}"></p>
            <p><label>Pulish Date: </label><input type="date" name="pdate" value="{{old('pdate')}}"></p>
            <p><label>Genre: </label><input type="text" name="genre" value="{{old('genre')}}"></p>
            <p><label>Description: </label><textarea rows="4" cols="50" name="description" value="{{old('description')}}"></textarea>
            <br>
            <input type="submit" value="Create"> 
        </form>
    </div>
@endsection