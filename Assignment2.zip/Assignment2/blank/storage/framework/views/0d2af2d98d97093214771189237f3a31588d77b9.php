<?php $__env->startSection('title'); ?>
    Photo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Upload a photo</h1>
    <?php if(count($errors) > 0): ?>
      <div class="alert">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <div class="form">
      <form method="POST" action="/album/<?php echo e($album_id); ?>/photo" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <p><input type="file" name="image"></p>
        <p><input type="hidden" name="album_id" value="<?php echo e($album_id); ?>"></p>
        <p><input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>"></p>
        <input type="submit" value="Create">
      </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>