<?php $__env->startSection('title'); ?>
  Adding review form
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <h1>Add Review</h1>
        <form method="post" action="/add_review_action" class="form">
            <?php echo e(csrf_field()); ?>

            <p>
              <label>User Name:</label>
              <input type="text" name="username">
            </p>
            <p>
              <label>Date:</label>
              <input type="text" name="rdate">
            </p>
            <p>
              <label>Review:</label>
              <input type="text" name="review">
            </p>
            <p>
              <label>Rating:</label>
              <input type="text" name="rating">
            </p>
            <p>
              <label>Album Name:</label>
              <input type="text" name="albumname">
            </p>
            <input type="submit" value="Submit">
      </form>
      <br>
  <?php if(!empty($eMessage)): ?>
    <p style="background-color:Tomato; width: 20%; padding: 15px 30px;"><?php echo e($eMessage); ?></p>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>