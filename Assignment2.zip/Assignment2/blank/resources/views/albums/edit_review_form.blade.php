@extends('layouts.app')

@section('title')
    Album
@endsection

@section('content')
    <h1>Edit the Review</h1>
    @if (count($errors) > 0)
      <div class="alert">
          <ul>
              @foreach ($errors->all() as $error)
                <li>{{$error}}</li>
              @endforeach
          </ul>
      </div>
    @endif
    <div class="edit">
        <form method="POST" action="/album/{{$album_id}}/review/{{$review->id}}">
        {{csrf_field()}}
        {{method_field('PUT')}}
            <p><input type="hidden" name="album_id" value="{{$review->album_id}}"></p>
            <p><input type="hidden" name="user_id" value="{{$review->user_id}}"></p>
            <p><label>Rating: </label><input type="number" name="rating" value="{{$review->rating}}"></p>
            <p><label>Review: </label><textarea rows="4" cols="50" name="review" value="{{$review->review}}"></textarea>
            <p><input type="hidden" name="like" value="{{$review->like}}"></p>
            <p><input type="hidden" name="dislike" value="{{$review->dislike}}"></p>
            <input type="submit" value="Update"> 
        </form>
    </div>
    
@endsection