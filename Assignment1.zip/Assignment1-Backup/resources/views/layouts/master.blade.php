<!DOCTYPE html>
<html>
<head>
  <title>@yield('title')</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="{{secure_asset('css/wp.css')}}">
</head>

<body>
  <div class="banner-image">
    <div class="banner-text">
    <h1>Welcome to the music world</h1>
    <p>Here you can have fun with music</p>
    </div>
  </div>
  <div id="navbar">
      <ul>
          <li><a href="/">Home</a></li>
          <li><a href="{{url("/albums")}}">Albums</a></li>
          <li><a href="{{url("/artists")}}">Artists</a></li>
          <li><a href="{{url("/genres")}}">Genres</a></li>
          <li><a href="{{url("/reviews")}}">Reviews</a></li>
          <li><a href="{{url("/ratings")}}">Rating</a></li>
          <li><a href="{{url("/document")}}">Document</a></li>
          <li><a href="{{url("/erd")}}">ER Diagram</a></li>
      </ul>
  </div>
  <br>
  <br>
    @yield('content')
</body>