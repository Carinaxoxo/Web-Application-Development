<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->insert([
            'first_name' => 'Taylor',
            'last_name' => 'Swift',
            'email' => 'TaylorSwift@gmail.com',
            'password' => bcrypt('123456'),
            'birthday' => '1997-01-04',
            'role' => 'regular',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
        ]);
        
        DB::table('users')->insert([
            'first_name' => 'Rich',
            'last_name' => 'Brain',
            'email' => 'RichBrain@gmail.com',
            'password' => bcrypt('123456'),
            'birthday' => '1997-01-04',
            'role' => 'regular',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
        ]);
        
        DB::table('users')->insert([
            'first_name' => 'Sam',
            'last_name' => 'Hunt',
            'email' => 'SamHunt@gmail.com',
            'password' => bcrypt('123456'),
            'birthday' => '1997-01-04',
            'role' => 'regular',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
        ]);
        
        DB::table('users')->insert([
            'first_name' => 'Yoga',
            'last_name' => 'Lin',
            'email' => 'YogaLin@gmail.com',
            'password' => bcrypt('123456'),
            'birthday' => '1997-01-04',
            'role' => 'regular',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
        ]);
        
        DB::table('users')->insert([
            'first_name' => 'Travis',
            'last_name' => 'Scott',
            'email' => 'TravisScott@gmail.com',
            'password' => bcrypt('123456'),
            'birthday' => '1997-01-04',
            'role' => 'regular',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
        ]);
        
        DB::table('users')->insert([
            'first_name' => 'Post',
            'last_name' => 'Malone',
            'email' => 'PostMalone@gmail.com',
            'password' => bcrypt('1234567'),
            'birthday' => '1997-01-04',
            'role' => 'moderator',
            'updated_at' => \DB::raw('CURRENT_TIMESTAMP'),
        ]);
    }
}
